<!-- Sidebar -->
<div class="sidebar">
    <h2>  <br><br><br>📦 SCM Dashboard</h2>
    <ul>
        <li><a href="home.php">🏠 Home</a></li>
        <li><a href="index.php">📋 Daftar Barang</a></li>
        <li><a href="karyawan.php">👥 Karyawan</a></li>
        <li><a href="laporan.php">📊 Laporan</a></li>
<li>
        <a href="#">📈 Visualisasi Interaktif</a>
        <ul style="padding-left: 15px;">
            <li><a href="matrik_kualitatif.php">🧠 Matrik Kualitatif</a></li>
            <li><a href="matrik_kuantitatif.php">📊 Matrik Kuantitatif</a></li>
        </ul>
    </li>
        <li><a href="log.php">📜 Log Aktivitas</a></li>
        <li><a href="logout.php">🔓 Logout</a></li>
    </ul>
</div>
